
public class Schulnote {

	public static void main(String[] args) {
	//Struktogramm
	int i = 1;
	
	while(i==5) {
		i = i+1;
	}
	//Noteberechnen
	double punkte = 29.0;
	double maximalpunkte = 34.0;
	double berechnung = (punkte/maximalpunkte)*5.0+1.0;
	
	System.out.println(berechnung);
	}
	
	
	
}
