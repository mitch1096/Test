package coin;

public interface Coin {
int toss();
}
