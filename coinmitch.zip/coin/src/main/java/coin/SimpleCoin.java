package coin;

public class SimpleCoin implements Coin {

	private boolean[] reg= {true,false,false,true};
	public int toss() {
	boolean next = reg[2]^reg[3];
	for (int i= reg.length -1; i>0; i--) {
reg[i] = reg[i-1];
}
	reg[0] = next;
	int res = reg[3]?1:0;
	return  res;
}
}