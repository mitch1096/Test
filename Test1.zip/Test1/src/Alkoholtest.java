
public class Alkoholtest {
	
private String Name;
private int alter;
private String typ;

public Alkoholtest(String name, int alter, String typ) {
	this.Name = name;
	this.alter = alter;
	this.typ = typ;
}

public int getAlter( String name) {
	int alter = 0;
	if(this.Name == name) {
		alter = this.alter;
	}
	return alter;
}

public String alkoholtest(int alter) {
	String kategorioe = "";
if(alter >= 18) {
	kategorioe = "harter Alkohol";
}
if(alter > 16 && alter < 18) {
	kategorioe = "weicher Akohol";
}
return kategorioe;
}

public void setName(String name) {
	this.Name = name;
}


public void StringtoString() {
	System.out.println("Name: "+this.Name+" Alter: "+this.alter+" Typ: "+this.typ);
}



}
