
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Alkoholtest h1 = new Alkoholtest("Mitch",26,"Mensch");
		
		h1.StringtoString();
		h1.setName("Dave");
		h1.StringtoString();
		
		
		System.out.println(h1.alkoholtest(17));
		
		String alkoholtyp = h1.alkoholtest(18);
		System.out.println(alkoholtyp);
	}
	
	

}
