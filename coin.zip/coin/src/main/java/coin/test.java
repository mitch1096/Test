package coin;

public class test{

	public static void main(String[] args) {
		Coin Coin = new SimpleCoin();
System.out.println(Coin.toss());
}
}
